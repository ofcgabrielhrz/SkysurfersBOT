pkg install nodejs -y
pkg install ffmpeg -y
pkg install imagemagick -y
git clone https://github.com/ilmanhdyt/ShiraoriBOT
npm install
npm update
